ALTER TABLE ONLY "icingaweb_rememberme"
    ALTER COLUMN random_iv type character varying(32);
