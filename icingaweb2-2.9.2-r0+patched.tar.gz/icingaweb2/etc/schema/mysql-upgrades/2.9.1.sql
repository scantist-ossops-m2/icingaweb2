ALTER TABLE `icingaweb_rememberme`
    MODIFY random_iv varchar(32)  NOT NULL;
