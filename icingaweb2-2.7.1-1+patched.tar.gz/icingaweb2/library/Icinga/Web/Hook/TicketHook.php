<?php
/* Icinga Web 2 | (c) 2014 Icinga Development Team | GPLv2+ */

namespace Icinga\Web\Hook;

use Icinga\Application\Hook\TicketHook as BaseHook;

/**
 * Deprecated, compat only.
 *
 * Please implement hooks in Icinga\Application\Hook
 */
abstract class TicketHook extends BaseHook
{
}
