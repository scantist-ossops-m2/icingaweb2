<?php
/* Icinga Web 2 | (c) 2019 Icinga GmbH | GPLv2+ */

namespace Icinga\Web\Form\Element;

class Checkbox extends \Zend_Form_Element_Checkbox
{
    public $helper = 'icingaCheckbox';
}
