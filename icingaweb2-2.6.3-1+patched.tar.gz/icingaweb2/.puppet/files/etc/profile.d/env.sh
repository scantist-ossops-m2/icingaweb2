export PATH="/opt/rh/rh-php71/root/bin:$PATH"
export PATH="$PATH:/usr/local/bin"
