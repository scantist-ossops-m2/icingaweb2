export PATH="/opt/rh/rh-php73/root/bin:$PATH"
export PATH="$PATH:/usr/local/bin"
