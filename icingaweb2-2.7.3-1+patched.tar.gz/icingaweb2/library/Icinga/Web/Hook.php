<?php
/* Icinga Web 2 | (c) 2013 Icinga Development Team | GPLv2+ */

namespace Icinga\Web;

use Icinga\Application\Hook as NewHookImplementation;

/**
 * Icinga Web Hook registry
 *
 * Deprecated, please use Icinga\Application\Hook instead
 */
class Hook extends NewHookImplementation
{
}
